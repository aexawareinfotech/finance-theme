<?php
/**
 * Plugin Name: Finance Theme - Custom Post Types
 * Plugin URI: https://github.com/aexaware/finance-theme
 * Description: Registers custom post types for testimonials, FAQs, and loan types for Finance Theme.
 * Version: 1.0.0
 * Author: Aexaware Infotech
 * Author URI: https://aexaware.com
 * Text Domain: finance-theme-cpt
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Custom Post Types
 */
function flavor_pt_register_post_types(): void
{
    // Testimonials
    register_post_type('testimonial', [
        'labels' => [
            'name' => __('Testimonials', 'finance-theme-cpt'),
            'singular_name' => __('Testimonial', 'finance-theme-cpt'),
            'add_new' => __('Add New', 'finance-theme-cpt'),
            'add_new_item' => __('Add New Testimonial', 'finance-theme-cpt'),
            'edit_item' => __('Edit Testimonial', 'finance-theme-cpt'),
            'new_item' => __('New Testimonial', 'finance-theme-cpt'),
            'view_item' => __('View Testimonial', 'finance-theme-cpt'),
            'search_items' => __('Search Testimonials', 'finance-theme-cpt'),
            'not_found' => __('No testimonials found', 'finance-theme-cpt'),
            'not_found_in_trash' => __('No testimonials found in Trash', 'finance-theme-cpt'),
        ],
        'public' => true,
        'has_archive' => false,
        'menu_icon' => 'dashicons-format-quote',
        'supports' => ['title', 'editor', 'thumbnail'],
        'show_in_rest' => true,
    ]);

    // FAQs
    register_post_type('faq', [
        'labels' => [
            'name' => __('FAQs', 'finance-theme-cpt'),
            'singular_name' => __('FAQ', 'finance-theme-cpt'),
            'add_new' => __('Add New', 'finance-theme-cpt'),
            'add_new_item' => __('Add New FAQ', 'finance-theme-cpt'),
            'edit_item' => __('Edit FAQ', 'finance-theme-cpt'),
            'new_item' => __('New FAQ', 'finance-theme-cpt'),
            'view_item' => __('View FAQ', 'finance-theme-cpt'),
            'search_items' => __('Search FAQs', 'finance-theme-cpt'),
            'not_found' => __('No FAQs found', 'finance-theme-cpt'),
            'not_found_in_trash' => __('No FAQs found in Trash', 'finance-theme-cpt'),
        ],
        'public' => true,
        'has_archive' => false,
        'menu_icon' => 'dashicons-editor-help',
        'supports' => ['title', 'editor'],
        'show_in_rest' => true,
    ]);

    // Loan Types
    register_post_type('loan_type', [
        'labels' => [
            'name' => __('Loan Types', 'finance-theme-cpt'),
            'singular_name' => __('Loan Type', 'finance-theme-cpt'),
            'add_new' => __('Add New', 'finance-theme-cpt'),
            'add_new_item' => __('Add New Loan Type', 'finance-theme-cpt'),
            'edit_item' => __('Edit Loan Type', 'finance-theme-cpt'),
            'new_item' => __('New Loan Type', 'finance-theme-cpt'),
            'view_item' => __('View Loan Type', 'finance-theme-cpt'),
            'search_items' => __('Search Loan Types', 'finance-theme-cpt'),
            'not_found' => __('No loan types found', 'finance-theme-cpt'),
            'not_found_in_trash' => __('No loan types found in Trash', 'finance-theme-cpt'),
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-money-alt',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'loans'],
    ]);
}
add_action('init', 'flavor_pt_register_post_types');

/**
 * Add custom meta boxes for testimonials
 */
function flavor_pt_add_testimonial_meta_boxes(): void
{
    add_meta_box(
        'testimonial_details',
        __('Testimonial Details', 'finance-theme-cpt'),
        'flavor_pt_testimonial_meta_box_callback',
        'testimonial',
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'flavor_pt_add_testimonial_meta_boxes');

/**
 * Meta box callback
 */
function flavor_pt_testimonial_meta_box_callback($post): void
{
    wp_nonce_field('flavor_pt_testimonial_meta', 'flavor_pt_testimonial_nonce');

    $rating = get_post_meta($post->ID, '_testimonial_rating', true);
    $loan_type = get_post_meta($post->ID, '_testimonial_loan_type', true);
    ?>
    <p>
        <label for="testimonial_rating"><strong>
                <?php esc_html_e('Rating (1-5):', 'finance-theme-cpt'); ?>
            </strong></label><br>
        <input type="number" id="testimonial_rating" name="testimonial_rating" value="<?php echo esc_attr($rating ?: 5); ?>"
            min="1" max="5" style="width: 60px;">
    </p>
    <p>
        <label for="testimonial_loan_type"><strong>
                <?php esc_html_e('Loan Type:', 'finance-theme-cpt'); ?>
            </strong></label><br>
        <input type="text" id="testimonial_loan_type" name="testimonial_loan_type"
            value="<?php echo esc_attr($loan_type); ?>" style="width: 100%;">
    </p>
    <?php
}

/**
 * Save meta box data
 */
function flavor_pt_save_testimonial_meta($post_id): void
{
    if (!isset($_POST['flavor_pt_testimonial_nonce'])) {
        return;
    }

    if (!wp_verify_nonce(sanitize_key($_POST['flavor_pt_testimonial_nonce']), 'flavor_pt_testimonial_meta')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['testimonial_rating'])) {
        update_post_meta($post_id, '_testimonial_rating', absint($_POST['testimonial_rating']));
    }

    if (isset($_POST['testimonial_loan_type'])) {
        update_post_meta($post_id, '_testimonial_loan_type', sanitize_text_field(wp_unslash($_POST['testimonial_loan_type'])));
    }
}
add_action('save_post_testimonial', 'flavor_pt_save_testimonial_meta');
