=== Finance Theme - Custom Post Types ===
Contributors: aexaware
Tags: finance, custom-post-types, testimonials, faq, loans
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Helper plugin for Finance Theme to register Custom Post Types.

== Description ==

This plugin is a required companion for the Finance Theme. It registers the following custom post types:
* Testimonials
* FAQs
* Loan Types

== Installation ==

This plugin acts as a bundled plugin with the theme.

== Changelog ==

= 1.0.0 =
* Initial release.
